import React from 'react'
import styles from './Header.module.css';
import Button from '../UI/Button';


const Header=(props)=> {

  return (
    <header className={styles.header}>
          <h1>I hate this React</h1>
          <Button className={styles.regiFormOpeningBtn} onClick={props.onOpenForm}>Registartion</Button>
          <Button className={styles.loginFormOpeningBtn} onClick={props.onShowLoginForm}>LOGIN</Button>

    </header>
  )
}

export default Header;
