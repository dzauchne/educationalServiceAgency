import React from 'react'
import styles from './UserList.module.css'

const UserList=(props)=> {
  return (
    <div >
        <ul>
        {props.users.map((user)=>(
        <li key='id'>{user.name}-{user.surname}-{user.age}лет-{user.email} </li>
        ))}
        </ul>
    </div>
  )
}
export default UserList;
