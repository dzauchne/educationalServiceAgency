import React from 'react';
import Button from '../UI/Button';

const InfoBtnForTutors=(props)=> {
  return (
    <>
    <Button>Info for Tutors</Button>
    </>
  )
}
export default InfoBtnForTutors;
