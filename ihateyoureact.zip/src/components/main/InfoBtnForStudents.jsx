import React from 'react';
import Button from '../UI/Button';

const InfoBtnForStudents=()=> {
  return (
    <>
    <Button>info for Students</Button>
    </>
  )
}
export default InfoBtnForStudents;
