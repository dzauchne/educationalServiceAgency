import React from 'react'

const Tutors=()=> {
  return (
    <div>to Tutors</div>
  )
}
export default Tutors;
