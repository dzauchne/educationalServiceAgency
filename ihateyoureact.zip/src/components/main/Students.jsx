
import React from 'react'

const Students=()=> {
  return (
    <div>to Students</div>
  )
}
export default Students;
