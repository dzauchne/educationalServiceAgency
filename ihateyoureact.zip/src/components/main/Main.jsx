import React, { Fragment } from 'react';
import styles from './Main.module.css';
import StudentsWorking from '../../assets/StudentsWorking.jpg';
// import AcademicSupport from '../../assets/AcademicSupport.jpg';
import InfoBtnForStudents from './InfoBtnForTutors';
import InfoBtnForTutors from './InfoBtnForTutors';
import Students from './Students';
import Tutors from './Tutors';
import Card from '../UI/Card';

const Main =(props)=> {

  return (
<>
    <div className={styles.main}>
        <h1>Why is it so hard to cope with JS? Why have I to red this React shirt every day and struggle with any baags and errors?</h1>
        <p>Because you want to fight against these problms to be satisfied with overcoming the next hurdle and many obstacles</p>
        <Card>
              <Tutors/>
              <InfoBtnForTutors/>
          </Card>
          <Card>
              <Students/>
              <InfoBtnForStudents/>
          </Card>
        <div className={styles['main-image']}>
            <img src={StudentsWorking} alt='студенческая работа'/>
            {/* <img src={AcademicSupport} alt='академическая поддержка'/> */}

        </div>
    </div>
    </>
  )
}

export default Main;
