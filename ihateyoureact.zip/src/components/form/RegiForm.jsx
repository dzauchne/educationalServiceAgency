import React, {useRef} from 'react';
import styles from './RegiForm.module.css';
import Button from '../UI/Button';
// import ErrorModal from '../UI/ErrorModal';
import { Fragment } from 'react';
// import ReactDOM from 'react-dom';

 const RegiForm=(props)=>{

// const[inputName, setInputName]=useState('');
// const[inputSurname, setInputSurname]=useState('');
// const[inputAge, setInputAge]=useState('');
// const[inputEmail, setInputEmail]=useState('');
// const[error, setError]=useState();
const nameInputRef=useRef();
const surnameInputRef=useRef();
const ageInputRef=useRef();
const emailInputRef=useRef();



    // const nameChangeHandler=(event)=>{
    //     setInputName(event.target.value);
    //   }


    //   const surnameChangeHandler=(event)=>{
    //     setInputSurname(event.target.value);
    //     }

    //   const ageChangeHandler=(event)=>{
    //     setInputAge(event.target.value);
    //   }


    //   const emailChangeHandler=(event)=>{
    //     setInputEmail(event.target.value);
    //   }


      const submitUserDataHandler=(event)=>{
        event.preventDefault();
        const inputUserName= nameInputRef.current.value;
        const inputUserSurname= surnameInputRef.current.value;
        const inputUserAge= ageInputRef.current.value;
        const inputUserEmail= nameInputRef.current.value;

        if(inputUserName.trim().length===0 || inputUserSurname.trim().length===0 || inputUserEmail.trim().length===0 || inputUserAge.trim().length===0){
        // setError({title:'Некорректный ввод!',
        // message:'Эти поля не могут быть пустыми, иначе Ваша регистрация не произойдёт!',})
        return;
        }

        if(+inputUserAge<1){
            // setError({title:'Некорректный ввод!',
            // message:'Возраст должен быть больше ноля!',})
            return;
        }
        props.onCreateUser(inputUserName, inputUserSurname, inputUserAge, inputUserEmail)

        nameInputRef.current.value="";
        surnameInputRef.current.value="";
        ageInputRef.current.value="";
        emailInputRef.current.value="";


 }
      // console.log(inputUserName, inputUserSurname, inputUserAge, inputUserEmail);

        console.log(inputUserName, inputUserSurname, inputUserAge, inputUserEmail)
// const errorHandler=()=>{
//   setError(false);
// }


  return (
    <Fragment>
       {/* {error &&  <ErrorModal onCloseErrorModal={errorHandler} title={error.title} message={error.message}/>} */}
      <div className={styles.backdrop}>
        <div className={styles.form} onSubmit={submitUserDataHandler}>
                <label htmlFor='name'>Имя*</label>
                <input id='name' type='text'  ref={nameInputRef}/>

                <label htmlFor='surname'>Фамилия*</label>
                <input id='surname' type='text' ref={surnameInputRef}/>

                <label htmlFor='age'>Возраст</label>
                <input id='age' type='number'  ref={ageInputRef}/>

                <label htmlFor='email'>Email*</label>
                <input id='email' type='text'  ref={emailInputRef}/>
            <Button className={styles.closeBtn} type='submit' onClick={props.onHideForm}>REGISTRATION</Button>
        </div>
    </div>
  </Fragment>
   );
};

export default RegiForm;
