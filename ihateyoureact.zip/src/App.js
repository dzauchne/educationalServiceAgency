import styles from './App.module.css';
import Header from './components/header/Header';
import Main from './components/main/Main';
import React, {useState} from 'react';
import RegiForm from './components/form/RegiForm';
import UserList from './components/users/UserList';
import Login from './components/login/Login';




const App =(props)=> {
  const [appearForm, setAppearForm]=useState(false);
  const [loginForm, setLoginForm]=useState(false);
  const [userList, setUserList]=useState([]);



  const showFormHandler=()=>{
        setAppearForm(true);
    }
    const hideFormHandler=()=>{
      setAppearForm(false);
    }

    const showLoginFormHandler=()=>{
      setLoginForm(true);
  }
  const hideLoginFormHandler=()=>{
    setLoginForm(false);
  }

    const createUserHandler=(name, surname, age, email)=>{
   setUserList((prevUserList)=>{
       return [...prevUserList,{name:name, surname:surname, age:age, email:email}]
   })
}


  return (
    <div className={styles.App}>
      <div>
          <Header onOpenForm={showFormHandler} onShowLoginForm={showLoginFormHandler}/>

          {appearForm && <RegiForm onHideForm={hideFormHandler} onCreateUser={createUserHandler} />}

         {loginForm && <Login onHideForm={hideLoginFormHandler} />}

          <div className={styles.userList}>
            <UserList users={userList} name={props.name} surname={props.surname} age={props.age} email={props.email}/>
            </div>

          <Main />
        </div>
    </div>
  );
}

export default App;
